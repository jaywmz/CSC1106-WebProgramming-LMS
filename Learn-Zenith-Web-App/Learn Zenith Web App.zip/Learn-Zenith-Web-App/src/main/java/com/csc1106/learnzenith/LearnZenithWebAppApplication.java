package com.csc1106.learnzenith;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnZenithWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnZenithWebAppApplication.class, args);
	}

}
