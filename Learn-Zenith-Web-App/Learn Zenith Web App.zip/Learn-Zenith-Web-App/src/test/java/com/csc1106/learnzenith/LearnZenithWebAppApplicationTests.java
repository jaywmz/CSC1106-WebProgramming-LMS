package com.csc1106.learnzenith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnZenithWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
